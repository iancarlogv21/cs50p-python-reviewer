# CS50P Python Reviewer TUI
#### Video Demo: https://youtu.be/YOUR_VIDEO_URL
#### Description:
The CS50P Python Reviewer TUI is an interactive terminal application designed for students mastering Python fundamentals. The software uses a structured JSON database (`questions.json`) containing 5 questions per module spanning Weeks 0 through 8 of CS50P.

Features include user session tracking, personalized history viewing restricted to the current user, randomized question shuffling, optional timed challenge mode, and a missed-questions review round. The interface uses the `rich` library for formatted panels, tables, and colored prompts.

### Files Included:
- `project.py`: Main application code handling menu logic, user prompts, scoring, and history logging.
- `questions.json`: Database of multiple-choice and identification questions.
- `test_project.py`: Pytest test suite for core logic validation.
- `requirements.txt`: Package dependency list (`rich`, `pytest`).
